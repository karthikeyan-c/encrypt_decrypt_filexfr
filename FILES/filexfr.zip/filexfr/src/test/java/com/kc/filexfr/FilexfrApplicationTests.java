package com.kc.filexfr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilexfrApplicationTests {

	@Test
	void contextLoads() {
	}

}
