package com.kc.filexfr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FilexfrApplication {

	public static void main(String[] args) {
		SpringApplication.run(FilexfrApplication.class, args);
	}

}
